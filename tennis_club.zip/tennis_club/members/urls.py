from django.urls import path
from . import views 
# We imported it so that we can setup url path to it


# It specifies which function in views.py to execute for which url
urlpatterns = [
    path('',views.main, name = 'main'),
    path('members/',views.members, name = 'members'),
    path('testing/', views.testing, name = 'test'),
    path('members/details/<int:id>', views.details, name = 'details'),
    # It captures an integer from the URL (which will correspond to
    #  the id of a specific member) and passes it as an argument to 
    # the details() view function.
    
]
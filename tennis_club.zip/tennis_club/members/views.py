# from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Member
from django.db.models import Q

# Create your views here.
def members(request):
    mymembers = Member.objects.all().values()
    # mymembers is now a dictionary containing fieldnames(primary) as keys 
    # and corresponding data to it as values

    template = loader.get_template('show_members.html')

    context = {
        'mymembers':mymembers,
    }

    # The context is a Python dictionary that contains the data you want
    # to pass to the template. 
    # In this case, it contains a key 'mymembers', which is assigned 
    # the value of the mymembers query result. 
    # This context will be used to dynamically render the data in HTML.

    

    # The render() method takes the context(data) and the request. 
    # It generates the final HTML content by replacing placeholders 
    # in the template with actual data from the context.

    return HttpResponse(template.render(context,request))

def details(request, id):
    mymember = Member.objects.get(id = id)
    template = loader.get_template('member_details.html')

    context = {
        'mymember':mymember,
    }

    return HttpResponse( template.render(context, request))

def main(request):
    template = loader.get_template('main.html')

    return HttpResponse(template.render())

def testing(request):
    template = loader.get_template('template.html')
    mydata = Member.objects.all().values()
    names = Member.objects.filter(firstname__startswith='s').order_by('-phone').values()

    context = {
        'fruits': ['apple','banana','orange'],
        'allmembers':mydata,
        'names':names
    }


    return HttpResponse(template.render(context,request))

